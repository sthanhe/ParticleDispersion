/* Automation Studio generated header file */
/* Do not edit ! */
/* FluBed  */

#ifndef _FLUBED_
#define _FLUBED_
#ifdef __cplusplus
extern "C" 
{
#endif

#include <bur/plctypes.h>

#ifndef _BUR_PUBLIC
#define _BUR_PUBLIC
#endif



/* Prototyping of functions and function blocks */
_BUR_PUBLIC float FluBed_wmf(float d_p, float rho_p, float p, float T);
_BUR_PUBLIC float FluBed_eps(float dp, float rho_p, float dh);
_BUR_PUBLIC float FluBed_h(float dp, float rho_p, float eps);
_BUR_PUBLIC float FluBed_dp(float h, float rho_p, float eps);


#ifdef __cplusplus
};
#endif
#endif /* _FLUBED_ */

