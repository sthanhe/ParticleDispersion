/* Automation Studio generated header file */
/* Do not edit ! */
/* FlowOrif  */

#ifndef _FLOWORIF_
#define _FLOWORIF_
#ifdef __cplusplus
extern "C" 
{
#endif

#include <bur/plctypes.h>

#ifndef _BUR_PUBLIC
#define _BUR_PUBLIC
#endif
/* Constants */
#ifdef _REPLACE_CONST
 #define pi 3.14159f
#else
 _GLOBAL_CONST float pi;
#endif




/* Datatypes and datatypes of function blocks */
typedef struct qm
{
	/* VAR_INPUT (analog) */
	float p1;
	float p2;
	float T1;
	float d;
	float D;
	unsigned char tap;
	/* VAR_OUTPUT (analog) */
	float mDot;
	float deltaOmega;
	/* VAR (analog) */
	float my1;
	float rho1;
	float kappa;
	float beta;
	float deltaP;
	float epsilon;
	float A1;
	float C;
	float err;
	float Re;
	float x;
	float y;
	unsigned char count;
} qm_typ;



/* Prototyping of functions and function blocks */
_BUR_PUBLIC void qm(struct qm* inst);
_BUR_PUBLIC float C_orifice(float Re, float d, float D, unsigned char tap);
_BUR_PUBLIC float epsOrifice(float p1, float p2, float kappa, float beta);


#ifdef __cplusplus
};
#endif
#endif /* _FLOWORIF_ */

