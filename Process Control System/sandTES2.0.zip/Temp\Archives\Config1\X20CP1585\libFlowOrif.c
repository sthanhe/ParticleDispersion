void qm(void) {};
void _qm(void) {};
void C_orifice(void) {};
void _C_orifice(void) {};
void epsOrifice(void) {};
void _epsOrifice(void) {};
