/* Automation Studio generated header file */
/* Do not edit ! */
/* PALemul  */

#ifndef _PALEMUL_
#define _PALEMUL_
#ifdef __cplusplus
extern "C" 
{
#endif

#include <bur/plctypes.h>

#ifndef _BUR_PUBLIC
#define _BUR_PUBLIC
#endif
/* Datatypes and datatypes of function blocks */
typedef struct PALemul_CmdFbDevInputs
{	plcbit Fb0;
	plcbit Fb1;
} PALemul_CmdFbDevInputs;

typedef struct PALemul_CmdFbInputs
{	plcbit Enable;
	plcbit UseAnalog;
	plcbit Fb0;
	plcbit Fb1;
	float YFb;
	float YTol;
	plctime DevTmPos;
	plctime DevTmNeg;
} PALemul_CmdFbInputs;

typedef struct PALemul_CmdFiltInputs
{	plcbit SetAuto;
	plcbit CmdMan;
	plcbit CmdAuto;
	plcbit Lck0;
	plcbit Lck1;
	plcbit CmdPri0;
	plcbit CmdPri1;
	plcbit CmdPriMan0;
	plcbit CmdPriMan1;
} PALemul_CmdFiltInputs;

typedef struct PALemul_WFiltInputs
{	plcbit SetWExt;
	float WInt;
	float WExt;
	float WMin;
	float WMax;
	float WRocUp;
	float WRocDown;
	plcbit DisRoc;
} PALemul_WFiltInputs;

typedef struct PALemul_WXDevInputs
{	float X;
	float WXDevLimPos;
	float WXDevLimNeg;
	plctime WXDevTmPos;
	plctime WXDevTmNeg;
} PALemul_WXDevInputs;

typedef struct PALemul_YFbDevInputs
{	float YFb;
	float YFbDevLimPos;
	float YFbDevLimNeg;
	plctime YFbDevTmPos;
	plctime YFbDevTmNeg;
} PALemul_YFbDevInputs;

typedef struct PALemul_YFiltInputs
{	plcbit SetAuto;
	float YMan;
	float YAuto;
	float YMin;
	float YMax;
	float YRocUp;
	float YRocDown;
	plcbit DisRoc;
} PALemul_YFiltInputs;

typedef struct PALemul_YFiltPIDInputs
{	plcbit SetAuto;
	plcbit SetOff;
	float YMan;
	float YAuto;
	float YOff;
	float YMin;
	float YMax;
	float YRocUp;
	float YRocDown;
	plcbit DisRoc;
	plcbit isActive;
} PALemul_YFiltPIDInputs;

typedef struct PALemul_YOutputsPID
{	float Yp;
	float Yi;
	float Yd;
	float Y;
} PALemul_YOutputsPID;

typedef struct PALemul_Ana2DigFb
{
	/* VAR_INPUT (analog) */
	float Y;
	float YMin;
	float YMax;
	float YTol;
	/* VAR_OUTPUT (digital) */
	plcbit Fb0;
	plcbit Fb1;
} PALemul_Ana2DigFb_typ;

typedef struct PALemul_FbFilt
{
	/* VAR_INPUT (analog) */
	float YMin;
	float YMax;
	struct PALemul_CmdFbInputs Config;
	/* VAR (analog) */
	struct PALemul_Ana2DigFb Ana2DigFb;
	/* VAR_INPUT (digital) */
	plcbit Cmd;
	/* VAR_OUTPUT (digital) */
	plcbit Fb0;
	plcbit Fb1;
	plcbit Fbx;
	/* VAR (digital) */
	plcbit DigFb0;
	plcbit DigFb1;
	plcbit AnaFb0;
	plcbit AnaFb1;
} PALemul_FbFilt_typ;

typedef struct PALemul_CmdFb
{
	/* VAR_INPUT (analog) */
	float YMin;
	float YMax;
	struct PALemul_CmdFbInputs Config;
	/* VAR_OUTPUT (analog) */
	unsigned char State;
	/* VAR (analog) */
	struct PALemul_FbFilt FbFilt;
	struct TON TON_0;
	struct TON TON_1;
	/* VAR_INPUT (digital) */
	plcbit Cmd;
	/* VAR_OUTPUT (digital) */
	plcbit Fb0;
	plcbit Fb1;
	plcbit isDev;
} PALemul_CmdFb_typ;

typedef struct PALemul_CmdFilt
{
	/* VAR_INPUT (analog) */
	struct PALemul_CmdFiltInputs CmdIn;
	unsigned char SafPos;
	/* VAR_OUTPUT (analog) */
	unsigned short CtrlStat;
	/* VAR_INPUT (digital) */
	plcbit ErrExt;
	/* VAR_OUTPUT (digital) */
	plcbit CmdOut;
	/* VAR (digital) */
	plcbit CmdOutOld;
} PALemul_CmdFilt_typ;

typedef struct PALemul_DigFb
{
	/* VAR_INPUT (analog) */
	float Y;
	float YMin;
	float YMax;
	struct PALemul_CmdFbInputs Config;
	/* VAR_OUTPUT (analog) */
	unsigned char State;
	/* VAR (analog) */
	struct PALemul_Ana2DigFb Ana2DigFb;
	struct TON TON_0;
	struct TON TON_1;
	/* VAR_INPUT (digital) */
	plcbit Disable;
	/* VAR_OUTPUT (digital) */
	plcbit Fb0;
	plcbit Fb1;
	plcbit isDev;
	/* VAR (digital) */
	plcbit Cmd0;
	plcbit Cmd1;
	plcbit Fbx;
} PALemul_DigFb_typ;

typedef struct PALemul_WFilt
{
	/* VAR_INPUT (analog) */
	float WInt;
	float WExt;
	float WMin;
	float WMax;
	float WRocUp;
	float WRocDown;
	unsigned char SafPos;
	/* VAR_OUTPUT (analog) */
	float WOut;
	/* VAR (analog) */
	float WIn;
	float ct;
	struct RF_TRIG RF_TRIG_0;
	struct RTInfo RTInfo_0;
	float WOutOld;
	/* VAR_INPUT (digital) */
	plcbit SetWExt;
	plcbit DisRoc;
	plcbit ErrExt;
} PALemul_WFilt_typ;

typedef struct PALemul_WFiltPacked
{
	/* VAR_INPUT (analog) */
	struct PALemul_WFiltInputs WPacked;
	unsigned char SafPos;
	/* VAR_OUTPUT (analog) */
	float WOut;
	/* VAR (analog) */
	struct PALemul_WFilt WFilt;
	/* VAR_INPUT (digital) */
	plcbit ErrExt;
} PALemul_WFiltPacked_typ;

typedef struct PALemul_WXDev
{
	/* VAR_INPUT (analog) */
	float W;
	struct PALemul_WXDevInputs Config;
	/* VAR (analog) */
	struct TON TON_pos;
	struct TON TON_neg;
	/* VAR_INPUT (digital) */
	plcbit Disable;
	/* VAR_OUTPUT (digital) */
	plcbit isDev;
} PALemul_WXDev_typ;

typedef struct PALemul_FCconv
{
	/* VAR_INPUT (analog) */
	struct PALemul_CmdFiltInputs Cmd;
	struct PALemul_WFiltInputs W;
	struct PALemul_CmdFbInputs CmdFbConf;
	struct PALemul_WXDevInputs WXDevConf;
	unsigned char SafPos;
	/* VAR_OUTPUT (analog) */
	float WOut;
	struct alarmCfg Alarm;
	unsigned char State;
	unsigned short CtrlStat;
	/* VAR (analog) */
	struct PALemul_CmdFilt CmdFilt;
	struct PALemul_WFiltPacked WFilt;
	struct PALemul_CmdFb CmdFb;
	struct PALemul_WXDev WXDev;
	/* VAR_INPUT (digital) */
	plcbit ErrExt;
	/* VAR_OUTPUT (digital) */
	plcbit CmdOut;
	plcbit Fb0;
	plcbit Fb1;
	plcbit CmdFbDevActive;
	plcbit WXDevActive;
} PALemul_FCconv_typ;

typedef struct PALemul_FC_BR
{
	/* VAR_INPUT (analog) */
	struct PALemul_CmdFiltInputs Cmd;
	struct PALemul_WFiltInputs W;
	unsigned short ETAD;
	signed short RFR;
	signed short OTR;
	unsigned short LCR;
	unsigned short THD;
	unsigned short THR;
	unsigned short ULN;
	unsigned short UOP;
	struct PALemul_CmdFbInputs CmdFbConf;
	struct PALemul_WXDevInputs WXDevConf;
	unsigned char SafPos;
	plctime OkTmLim;
	/* VAR_OUTPUT (analog) */
	unsigned short CMDD;
	signed short LFR;
	float SpdAct;
	float MotTor;
	float MotCur;
	float DrvThmStat;
	float MotThmStat;
	float MainVlt;
	float MotVlt;
	struct alarmCfg Alarm;
	unsigned char State;
	unsigned short CtrlStat;
	/* VAR (analog) */
	struct PALemul_CmdFilt CmdFilt;
	struct PALemul_WFiltPacked WFilt;
	struct PALemul_CmdFb CmdFb;
	struct PALemul_WXDev WXDev;
	struct TOF Delay;
	plcword ETAD_word;
	plcword CMDD_word;
	/* VAR_INPUT (digital) */
	plcbit Halt;
	plcbit emStop;
	plcbit Ack;
	plcbit ModuleOk;
	plcbit ErrExt;
	/* VAR_OUTPUT (digital) */
	plcbit Fb0;
	plcbit Fb1;
	plcbit CmdFbDevActive;
	plcbit WXDevActive;
} PALemul_FC_BR_typ;

typedef struct PALemul_YFbDevPacked
{
	/* VAR_INPUT (analog) */
	float Y;
	struct PALemul_YFbDevInputs Config;
	/* VAR (analog) */
	struct PALemul_WXDev YFbDev;
	/* VAR_INPUT (digital) */
	plcbit Disable;
	/* VAR_OUTPUT (digital) */
	plcbit isDev;
} PALemul_YFbDevPacked_typ;

typedef struct PALemul_PID
{
	/* VAR_INPUT (analog) */
	struct PALemul_YFiltPIDInputs Y;
	struct PALemul_WFiltInputs W;
	float X;
	float Kp;
	float Ti;
	float Td;
	float a;
	struct PALemul_CmdFbInputs DigFbConf;
	struct PALemul_YFbDevInputs YFbDevConf;
	struct PALemul_WXDevInputs WXDevConf;
	unsigned char SafPos;
	/* VAR_OUTPUT (analog) */
	float WOut;
	struct PALemul_YOutputsPID YOut;
	float e;
	struct alarmCfg Alarm;
	/* VAR (analog) */
	struct PALemul_WFilt YFilt;
	struct PALemul_WFiltPacked WFilt;
	struct PALemul_WFiltPacked WFiltInt;
	struct PALemul_DigFb DigFb;
	struct PALemul_YFbDevPacked YFbDev;
	struct PALemul_WXDev WXDev;
	struct MTBasicsPID PID;
	struct F_TRIG F_TRIG_0;
	struct F_TRIG F_TRIG_1;
	struct R_TRIG R_TRIG_0;
	/* VAR_INPUT (digital) */
	plcbit CtrlDirIvt;
	plcbit CmdPri0;
	plcbit CmdPri1;
	plcbit CmdPri2;
	plcbit CmdPriMan0;
	plcbit CmdPriMan1;
	plcbit CmdPriMan2;
	plcbit ErrExt;
	/* VAR_OUTPUT (digital) */
	plcbit Fb0;
	plcbit Fb1;
	plcbit DigFbDevActive;
	plcbit YFbDevActive;
	plcbit WXDevActive;
	plcbit DisRoc;
	/* VAR (digital) */
	plcbit Error;
	plcbit NoCmdPri;
} PALemul_PID_typ;

typedef struct PALemul_YFiltPacked
{
	/* VAR_INPUT (analog) */
	struct PALemul_YFiltInputs YPacked;
	unsigned char SafPos;
	/* VAR_OUTPUT (analog) */
	float YOut;
	/* VAR (analog) */
	struct PALemul_WFilt YFilt;
	/* VAR_INPUT (digital) */
	plcbit ErrExt;
} PALemul_YFiltPacked_typ;

typedef struct PALemul_ValveAna
{
	/* VAR_INPUT (analog) */
	struct PALemul_YFiltInputs YSet;
	struct PALemul_CmdFbInputs DigFbConf;
	struct PALemul_YFbDevInputs YFbDevConf;
	unsigned char SafPos;
	/* VAR_OUTPUT (analog) */
	float YOut;
	struct alarmCfg Alarm;
	unsigned char State;
	/* VAR (analog) */
	struct PALemul_YFiltPacked YFilt;
	struct PALemul_DigFb DigFb;
	struct PALemul_YFbDevPacked YFbDev;
	float YOutOld;
	/* VAR_INPUT (digital) */
	plcbit CmdPri0;
	plcbit CmdPri1;
	plcbit CmdPriMan0;
	plcbit CmdPriMan1;
	plcbit ErrExt;
	/* VAR_OUTPUT (digital) */
	plcbit Fb0;
	plcbit Fb1;
	plcbit DigFbDevActive;
	plcbit YFbDevActive;
} PALemul_ValveAna_typ;

typedef struct PALemul_ValveDig
{
	/* VAR_INPUT (analog) */
	struct PALemul_CmdFiltInputs Cmd;
	struct PALemul_CmdFbInputs CmdFbConf;
	unsigned char SafPos;
	/* VAR_OUTPUT (analog) */
	struct alarmCfg Alarm;
	unsigned char State;
	unsigned short CtrlStat;
	/* VAR (analog) */
	struct PALemul_CmdFilt CmdFilt;
	struct PALemul_CmdFb CmdFb;
	/* VAR_INPUT (digital) */
	plcbit ErrExt;
	/* VAR_OUTPUT (digital) */
	plcbit CmdOut;
	plcbit Fb0;
	plcbit Fb1;
	plcbit CmdFbDevActive;
} PALemul_ValveDig_typ;



/* Prototyping of functions and function blocks */
_BUR_PUBLIC void PALemul_Ana2DigFb(struct PALemul_Ana2DigFb* inst);
_BUR_PUBLIC void PALemul_CmdFb(struct PALemul_CmdFb* inst);
_BUR_PUBLIC void PALemul_CmdFilt(struct PALemul_CmdFilt* inst);
_BUR_PUBLIC void PALemul_DigFb(struct PALemul_DigFb* inst);
_BUR_PUBLIC void PALemul_FbFilt(struct PALemul_FbFilt* inst);
_BUR_PUBLIC void PALemul_FCconv(struct PALemul_FCconv* inst);
_BUR_PUBLIC void PALemul_FC_BR(struct PALemul_FC_BR* inst);
_BUR_PUBLIC void PALemul_PID(struct PALemul_PID* inst);
_BUR_PUBLIC void PALemul_ValveAna(struct PALemul_ValveAna* inst);
_BUR_PUBLIC void PALemul_ValveDig(struct PALemul_ValveDig* inst);
_BUR_PUBLIC void PALemul_WFilt(struct PALemul_WFilt* inst);
_BUR_PUBLIC void PALemul_WFiltPacked(struct PALemul_WFiltPacked* inst);
_BUR_PUBLIC void PALemul_WXDev(struct PALemul_WXDev* inst);
_BUR_PUBLIC void PALemul_YFbDevPacked(struct PALemul_YFbDevPacked* inst);
_BUR_PUBLIC void PALemul_YFiltPacked(struct PALemul_YFiltPacked* inst);


#ifdef __cplusplus
};
#endif
#endif /* _PALEMUL_ */

