/* Automation Studio generated header file */
/* Do not edit ! */
/* DryAir  */

#ifndef _DRYAIR_
#define _DRYAIR_
#ifdef __cplusplus
extern "C" 
{
#endif

#include <bur/plctypes.h>

#ifndef _BUR_PUBLIC
#define _BUR_PUBLIC
#endif
/* Constants */
#ifdef _REPLACE_CONST
 #define R_A 287.12f
#else
 _GLOBAL_CONST float R_A;
#endif







/* Prototyping of functions and function blocks */
_BUR_PUBLIC float DryAir_eta(float T);
_BUR_PUBLIC float DryAir_kappa(float T);
_BUR_PUBLIC float DryAir_rho(float p, float T);


#ifdef __cplusplus
};
#endif
#endif /* _DRYAIR_ */

