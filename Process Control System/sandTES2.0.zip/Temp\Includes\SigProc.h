/* Automation Studio generated header file */
/* Do not edit ! */
/* SigProc  */

#ifndef _SIGPROC_
#define _SIGPROC_
#ifdef __cplusplus
extern "C" 
{
#endif

#include <bur/plctypes.h>

#ifndef _BUR_PUBLIC
#define _BUR_PUBLIC
#endif
/* Datatypes and datatypes of function blocks */
typedef struct check420Outputs
{	plcbit outOfRange;
	plcbit overRange;
	plcbit underRange;
	plcbit moduleFail;
	plcbit wireBreak;
} check420Outputs;

typedef struct SignalLimit
{	plcbit Check;
	float Low;
	float High;
	plcbit DisLow;
	plcbit DisHigh;
} SignalLimit;

typedef struct SignalQuality
{	plcbit ModuleOk;
	plcbit StaleData;
	plcbit ConvertionCycle;
	plcbit SyncStatus;
	plcbit ChannelOk;
	plcbit ChannelUnderflow;
	plcbit ChannelOverflow;
	plcbit WireBreak;
} SignalQuality;

typedef struct SignalQualityAO
{	plcbit ModuleOk;
} SignalQualityAO;

typedef struct SignalQualityAP3131
{	plcbit ModuleOk;
	plcbit StaleData;
	unsigned short SysStatus1;
} SignalQualityAP3131;

typedef struct SignalQualityATB312
{	plcbit ModuleOk;
	plcbit StaleData;
	unsigned char Status;
} SignalQualityATB312;

typedef struct SignalQualityDO
{	plcbit ModuleOk;
	plcbit Status;
} SignalQualityDO;

typedef struct SignalRange
{	float Begin;
	float End;
} SignalRange;

typedef struct SignalSubstitution
{	plcbit Apply;
	plcbit ApplyOnStartup;
	unsigned char Type;
	float CustomValue;
} SignalSubstitution;

typedef struct SignalSubstitutionDigital
{	plcbit Apply;
	plcbit ApplyOnStartup;
	unsigned char Type;
	plcbit CustomValue;
} SignalSubstitutionDigital;

typedef struct SignalVolatility
{	struct SignalLimit Abs;
	struct SignalLimit Rel;
	plctime Interval;
} SignalVolatility;

typedef struct SigProcVolatility
{
	/* VAR_INPUT (analog) */
	float Signal;
	struct SignalVolatility Cfg;
	/* VAR (analog) */
	struct MTFilterMovingAverage MovAvg;
	unsigned short WindowLength;
	float ct;
	struct RTInfo RTInfo_0;
	/* VAR_OUTPUT (digital) */
	plcbit isVolatile;
	plcbit isVolatileAbs;
	plcbit isVolatileRel;
} SigProcVolatility_typ;

typedef struct SigProcAI
{
	/* VAR_INPUT (analog) */
	float In;
	struct SignalRange Range;
	struct SignalLimit Lim;
	struct SignalVolatility Vola;
	struct SignalSubstitution SubsVal;
	plctime OkTmLim;
	/* VAR_OUTPUT (analog) */
	float Out;
	/* VAR (analog) */
	struct SigProcVolatility Volatility;
	struct TOF Delay;
	float OutOld;
	/* VAR_INPUT (digital) */
	plcbit InOk;
	plcbit OkBypass;
	/* VAR_OUTPUT (digital) */
	plcbit OutOk;
	plcbit CascOk;
	/* VAR (digital) */
	plcbit isStartup;
} SigProcAI_typ;

typedef struct SigProcAI4632
{
	/* VAR_INPUT (analog) */
	signed short Signal;
	unsigned char Type;
	struct SignalRange Range;
	struct SignalQuality Qual;
	struct SignalLimit Lim;
	struct SignalVolatility Vola;
	struct SignalSubstitution SubsVal;
	plctime OkTmLim;
	/* VAR_OUTPUT (analog) */
	float Value;
	/* VAR (analog) */
	struct SigProcAI ConsCheck;
	/* VAR_INPUT (digital) */
	plcbit OkBypass;
	/* VAR_OUTPUT (digital) */
	plcbit Ok;
	plcbit CascOk;
} SigProcAI4632_typ;

typedef struct SigProcAO
{
	/* VAR_INPUT (analog) */
	float In;
	struct SignalRange Range;
	struct SignalSubstitution SubsVal;
	/* VAR_OUTPUT (analog) */
	float Out;
	/* VAR (analog) */
	float OutOld;
	/* VAR_INPUT (digital) */
	plcbit Ok;
	/* VAR (digital) */
	plcbit isStartup;
} SigProcAO_typ;

typedef struct SigProcAO4622
{
	/* VAR_INPUT (analog) */
	float Value;
	unsigned char Type;
	struct SignalRange Range;
	struct SignalQualityAO Qual;
	struct SignalSubstitution SubsVal;
	plctime OkTmLim;
	/* VAR_OUTPUT (analog) */
	signed short Signal;
	/* VAR (analog) */
	struct SigProcAO ConsCheck;
	struct TOF Delay;
	/* VAR_INPUT (digital) */
	plcbit OkBypass;
	/* VAR_OUTPUT (digital) */
	plcbit Ok;
	plcbit CascOk;
} SigProcAO4622_typ;

typedef struct SigProcAO4632
{
	/* VAR_INPUT (analog) */
	float Value;
	unsigned char Type;
	struct SignalRange Range;
	struct SignalQualityAO Qual;
	struct SignalSubstitution SubsVal;
	plctime OkTmLim;
	/* VAR_OUTPUT (analog) */
	signed short Signal;
	/* VAR (analog) */
	struct SigProcAO ConsCheck;
	struct TOF Delay;
	/* VAR_INPUT (digital) */
	plcbit OkBypass;
	/* VAR_OUTPUT (digital) */
	plcbit Ok;
	plcbit CascOk;
} SigProcAO4632_typ;

typedef struct SigProcAP3131
{
	/* VAR_INPUT (analog) */
	unsigned short IrmsSignal;
	unsigned short UrmsSignal;
	signed short PmeanSignal;
	signed short QmeanSignal;
	signed short SmeanSignal;
	signed short PFmeanSignal;
	signed short UAngleSignal;
	signed short PAngleSignal;
	struct SignalQualityAP3131 Qual;
	plctime OkTmLim;
	/* VAR_OUTPUT (analog) */
	float Irms;
	float Urms;
	float Pmean;
	float Qmean;
	float Smean;
	float PFmean;
	float UAngle;
	float PAngle;
	/* VAR (analog) */
	struct TOF Delay;
	/* VAR_INPUT (digital) */
	plcbit OkBypass;
	/* VAR_OUTPUT (digital) */
	plcbit Ok;
	plcbit CascOk;
} SigProcAP3131_typ;

typedef struct SigProcAP3131Oversampling
{
	/* VAR_INPUT (analog) */
	unsigned short IrmsSignal;
	unsigned short UrmsSignal;
	signed short PmeanSignal;
	signed short QmeanSignal;
	signed short SmeanSignal;
	signed short PFmeanSignal;
	signed short UAngleSignal;
	signed short PAngleSignal;
	struct SignalQualityAP3131 Qual;
	plctime OkTmLim;
	/* VAR_OUTPUT (analog) */
	float Irms;
	float Urms;
	float Pmean;
	float Qmean;
	float Smean;
	float PFmean;
	float UAngle;
	float PAngle;
	/* VAR (analog) */
	struct TOF Delay;
	/* VAR_INPUT (digital) */
	plcbit OkBypass;
	/* VAR_OUTPUT (digital) */
	plcbit Ok;
	plcbit CascOk;
} SigProcAP3131Oversampling_typ;

typedef struct SigProcATB312
{
	/* VAR_INPUT (analog) */
	signed long Signal;
	struct SignalRange Range;
	struct SignalQualityATB312 Qual;
	struct SignalLimit Lim;
	struct SignalVolatility Vola;
	struct SignalSubstitution SubsVal;
	plctime OkTmLim;
	/* VAR_OUTPUT (analog) */
	float Value;
	/* VAR (analog) */
	struct SigProcAI ConsCheck;
	/* VAR_INPUT (digital) */
	plcbit OkBypass;
	/* VAR_OUTPUT (digital) */
	plcbit Ok;
	plcbit CascOk;
} SigProcATB312_typ;

typedef struct SigProcDIO
{
	/* VAR_INPUT (analog) */
	struct SignalSubstitutionDigital SubsVal;
	/* VAR_INPUT (digital) */
	plcbit In;
	plcbit Ok;
	/* VAR_OUTPUT (digital) */
	plcbit Out;
	/* VAR (digital) */
	plcbit OutOld;
	plcbit isStartup;
} SigProcDIO_typ;

typedef struct SigProcDI9371
{
	/* VAR_INPUT (analog) */
	struct SignalQualityAO Qual;
	struct SignalSubstitutionDigital SubsVal;
	plctime OkTmLim;
	/* VAR (analog) */
	struct SigProcDIO ConsCheck;
	struct TOF Delay;
	/* VAR_INPUT (digital) */
	plcbit Signal;
	plcbit OkBypass;
	/* VAR_OUTPUT (digital) */
	plcbit Value;
	plcbit Ok;
	plcbit CascOk;
} SigProcDI9371_typ;

typedef struct SigProcDO9322
{
	/* VAR_INPUT (analog) */
	struct SignalQualityDO Qual;
	struct SignalSubstitutionDigital SubsVal;
	plctime OkTmLim;
	/* VAR (analog) */
	struct SigProcDIO ConsCheck;
	struct TOF Delay;
	/* VAR_INPUT (digital) */
	plcbit Value;
	plcbit Inverted;
	plcbit OkBypass;
	/* VAR_OUTPUT (digital) */
	plcbit Signal;
	plcbit Ok;
	plcbit CascOk;
} SigProcDO9322_typ;



/* Prototyping of functions and function blocks */
_BUR_PUBLIC void SigProcAI(struct SigProcAI* inst);
_BUR_PUBLIC void SigProcAI4632(struct SigProcAI4632* inst);
_BUR_PUBLIC void SigProcAO(struct SigProcAO* inst);
_BUR_PUBLIC void SigProcAO4622(struct SigProcAO4622* inst);
_BUR_PUBLIC void SigProcAO4632(struct SigProcAO4632* inst);
_BUR_PUBLIC void SigProcAP3131(struct SigProcAP3131* inst);
_BUR_PUBLIC void SigProcAP3131Oversampling(struct SigProcAP3131Oversampling* inst);
_BUR_PUBLIC void SigProcATB312(struct SigProcATB312* inst);
_BUR_PUBLIC void SigProcDI9371(struct SigProcDI9371* inst);
_BUR_PUBLIC void SigProcDIO(struct SigProcDIO* inst);
_BUR_PUBLIC void SigProcDO9322(struct SigProcDO9322* inst);
_BUR_PUBLIC void SigProcVolatility(struct SigProcVolatility* inst);
_BUR_PUBLIC float SigProcMap010(signed short Signal, struct SignalRange* Range);
_BUR_PUBLIC signed short SigProcMap010Out(float Value, struct SignalRange* Range);
_BUR_PUBLIC float SigProcMap420(signed short Signal, struct SignalRange* Range);
_BUR_PUBLIC signed short SigProcMap420Out(float Value, struct SignalRange* Range);
_BUR_PUBLIC float SigProcMapPM10(signed short Signal, struct SignalRange* Range);
_BUR_PUBLIC signed short SigProcMapPM10Out(float Value, struct SignalRange* Range);


#ifdef __cplusplus
};
#endif
#endif /* _SIGPROC_ */

