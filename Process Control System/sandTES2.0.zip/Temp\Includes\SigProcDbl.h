/* Automation Studio generated header file */
/* Do not edit ! */
/* SigProcDbl  */

#ifndef _SIGPROCDBL_
#define _SIGPROCDBL_
#ifdef __cplusplus
extern "C" 
{
#endif

#include <bur/plctypes.h>

#ifndef _BUR_PUBLIC
#define _BUR_PUBLIC
#endif
/* Datatypes and datatypes of function blocks */
typedef struct DoubleLimit
{	plcbit Check;
	double Low;
	double High;
	plcbit DisLow;
	plcbit DisHigh;
} DoubleLimit;

typedef struct DoubleQuality
{	plcbit ModuleOk;
	plcbit StaleData;
	plcbit ConvertionCycle;
	plcbit SyncStatus;
	plcbit ChannelOk;
	plcbit ChannelUnderflow;
	plcbit ChannelOverflow;
	plcbit WireBreak;
} DoubleQuality;

typedef struct DoubleRange
{	double Begin;
	double End;
} DoubleRange;

typedef struct DoubleSubstitution
{	plcbit Apply;
	plcbit ApplyOnStartup;
	unsigned char Type;
	double CustomValue;
} DoubleSubstitution;

typedef struct DoubleVolatility
{	struct DoubleLimit Abs;
	struct DoubleLimit Rel;
	plctime Interval;
} DoubleVolatility;

typedef struct SigProcDblVolatility
{
	/* VAR_INPUT (analog) */
	double Signal;
	struct DoubleVolatility Cfg;
	/* VAR (analog) */
	struct MTFilterMovingAverage MovAvg;
	unsigned short WindowLength;
	float ct;
	struct RTInfo RTInfo_0;
	/* VAR_OUTPUT (digital) */
	plcbit isVolatile;
	plcbit isVolatileAbs;
	plcbit isVolatileRel;
} SigProcDblVolatility_typ;

typedef struct SigProcDblAI
{
	/* VAR_INPUT (analog) */
	double In;
	struct DoubleRange Range;
	struct DoubleLimit Lim;
	struct DoubleVolatility Vola;
	struct DoubleSubstitution SubsVal;
	plctime OkTmLim;
	/* VAR_OUTPUT (analog) */
	double Out;
	/* VAR (analog) */
	struct SigProcDblVolatility Volatility;
	struct TOF Delay;
	double OutOld;
	/* VAR_INPUT (digital) */
	plcbit InOk;
	plcbit OkBypass;
	/* VAR_OUTPUT (digital) */
	plcbit OutOk;
	plcbit CascOk;
	/* VAR (digital) */
	plcbit isStartup;
} SigProcDblAI_typ;



/* Prototyping of functions and function blocks */
_BUR_PUBLIC void SigProcDblAI(struct SigProcDblAI* inst);
_BUR_PUBLIC void SigProcDblVolatility(struct SigProcDblVolatility* inst);


#ifdef __cplusplus
};
#endif
#endif /* _SIGPROCDBL_ */

