void SigProcDblAI(void) {};
void _SigProcDblAI(void) {};
void SigProcDblVolatility(void) {};
void _SigProcDblVolatility(void) {};
