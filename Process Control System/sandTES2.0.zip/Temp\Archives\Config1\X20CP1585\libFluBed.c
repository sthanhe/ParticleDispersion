void FluBed_wmf(void) {};
void _FluBed_wmf(void) {};
void FluBed_eps(void) {};
void _FluBed_eps(void) {};
void FluBed_h(void) {};
void _FluBed_h(void) {};
void FluBed_dp(void) {};
void _FluBed_dp(void) {};
