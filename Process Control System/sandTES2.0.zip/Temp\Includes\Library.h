/* Automation Studio generated header file */
/* Do not edit ! */
/* Library  */

#ifndef _LIBRARY_
#define _LIBRARY_
#ifdef __cplusplus
extern "C" 
{
#endif

#include <bur/plctypes.h>

#ifndef _BUR_PUBLIC
#define _BUR_PUBLIC
#endif
/* Constants */
#ifdef _REPLACE_CONST
 #define g 9.81f
#else
 _GLOBAL_CONST float g;
#endif




/* Datatypes and datatypes of function blocks */
typedef struct alarmCfg
{
	/* VAR_INPUT (analog) */
	unsigned char n;
	/* VAR (analog) */
	unsigned char i;
	struct F_TRIG F_TRIG_0;
	/* VAR_INPUT (digital) */
	plcbit In[256];
	plcbit Ack[256];
	plcbit Bypass[256];
	plcbit Lock[256];
	plcbit Group;
	plcbit ResetMan;
	/* VAR_OUTPUT (digital) */
	plcbit State[256];
	plcbit Reset[256];
	plcbit Any;
} alarmCfg_typ;

typedef struct deriv
{
	/* VAR_INPUT (analog) */
	float In;
	unsigned short WindowLength;
	/* VAR_OUTPUT (analog) */
	float Out;
	/* VAR (analog) */
	float values[10001];
	unsigned short i;
	unsigned short MaxWindowLength;
} deriv_typ;

typedef struct uint2binary
{
	/* VAR_INPUT (analog) */
	unsigned short In;
	/* VAR_OUTPUT (analog) */
	unsigned short Out;
	/* VAR (analog) */
	unsigned short rem;
	float exponent;
	float exponentApprox;
} uint2binary_typ;

typedef struct word2bytes
{
	/* VAR_INPUT (analog) */
	plcword word1;
	/* VAR_OUTPUT (analog) */
	plcbyte byte1;
	plcbyte byte2;
} word2bytes_typ;



/* Prototyping of functions and function blocks */
_BUR_PUBLIC void alarmCfg(struct alarmCfg* inst);
_BUR_PUBLIC void deriv(struct deriv* inst);
_BUR_PUBLIC void uint2binary(struct uint2binary* inst);
_BUR_PUBLIC void word2bytes(struct word2bytes* inst);
_BUR_PUBLIC float at6402toK(signed short signal);
_BUR_PUBLIC plcword bytes2word(plcbyte byte1, plcbyte byte2);
_BUR_PUBLIC float cycleTime();
_BUR_PUBLIC plcdword words2dword(plcword word1, plcword word2);


#ifdef __cplusplus
};
#endif
#endif /* _LIBRARY_ */

